<!--
IMPORTANT: Please provide as much information as possible:

    - Reporting a bug: if possible provide a repro on jsfiddle.net or a stacktrace at the very least

    - Feature request: lay out the reasoning behind it and propose an API for it

-->
